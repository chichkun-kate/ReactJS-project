import ProfileContainer from './containers/ProfileContainer'

export default ProfileContainer
