import NotFoundView from './components/NotFoundView'

export default NotFoundView
