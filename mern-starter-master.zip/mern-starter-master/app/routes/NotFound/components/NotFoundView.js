import React from 'react'

const NotFoundView = () => (
  <h2>Not Found</h2>
)

export default NotFoundView
