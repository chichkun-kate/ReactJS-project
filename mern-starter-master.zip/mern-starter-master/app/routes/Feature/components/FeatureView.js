import React from 'react'

export default () => (
  <div>
    <h1>Features</h1>
  </div>
)
