import FeatureView from './components/FeatureView'

export default FeatureView
