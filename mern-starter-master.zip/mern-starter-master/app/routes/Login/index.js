import LoginContainer from './containers/LoginContainer'

export default LoginContainer
