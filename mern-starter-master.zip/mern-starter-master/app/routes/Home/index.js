import HomeView from './components/HomeView'

export default HomeView
