import ListContainer from './containers/ListContainer'
import EditContainer from './containers/EditContainer'

export default {
  List: ListContainer,
  Edit: EditContainer,
}
