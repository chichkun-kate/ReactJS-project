export const USER_TYPE_ADMIN = 'ADMIN'
export const USER_TYPE_USER = 'USER'

export const USER_TYPES = [
  USER_TYPE_ADMIN,
  USER_TYPE_USER,
]
