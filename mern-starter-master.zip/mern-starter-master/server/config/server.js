export default {
  DB_URI: 'mongodb://127.0.0.1/mern',
  SESSION_SECRET: 'YOUR_SECRET_GOES_HERE',
  DEFAULT_USER: {
    username: 'admin',
    password: 'admin',
  },
}
